#ifndef DD_DHT_H_
#define DD_DHT_H_


void dd_dht_setup();
void dd_dht_loop();
int dd_dht_GetError();
float dd_dht_GetTemperature();


#endif