#ifndef SRV_UI_SERIAL_H_
#define SRV_UI_SERIAL_H_

void srv_ui_serial_setup();
void srv_ui_serial_loop();



#endif